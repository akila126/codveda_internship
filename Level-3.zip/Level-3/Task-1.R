# ============================================================
# Level 3 | Task 1: Predictive Analytics & Machine Learning
# ============================================================

install.packages("dplyr")
install.packages("readr")
install.packages("caret")
install.packages("ggplot2")

library(dplyr)
library(readr)
library(caret)
library(ggplot2)

columns <- c("CRIM","ZN","INDUS","CHAS","NOX","RM","AGE","DIS",
             "RAD","TAX","PTRATIO","B","LSTAT","MEDV")
house <- read_table("4) house Prediction Data Set.csv", col_names = columns)

set.seed(42)
train_idx <- createDataPartition(house$MEDV, p = 0.8, list = FALSE)
train_data <- house[train_idx, ]
test_data  <- house[-train_idx, ]

reg_model <- lm(MEDV ~ ., data = train_data)
summary(reg_model)

predictions <- predict(reg_model, test_data)
rmse <- sqrt(mean((predictions - test_data$MEDV)^2))
cat("Regression RMSE:", round(rmse, 2), "\n")

churn <- read_csv("churn-bigml-80.csv")
churn$Churn <- as.factor(churn$Churn)

set.seed(42)
train_idx2 <- createDataPartition(churn$Churn, p = 0.8, list = FALSE)
train_c <- churn[train_idx2, ]
test_c  <- churn[-train_idx2, ]

log_model <- glm(Churn ~ `Customer service calls` + `International plan` +
                   `Total day minutes` + `Account length`,
                 data = train_c, family = "binomial")
summary(log_model)

probs <- predict(log_model, test_c, type = "response")
preds <- ifelse(probs > 0.5, "TRUE", "FALSE")

cat("\n=== BASELINE MODEL (0.5 cutoff, imbalanced) ===\n")
print(confusionMatrix(as.factor(preds), as.factor(test_c$Churn)))

preds_adj <- ifelse(probs > 0.25, "TRUE", "FALSE")

cat("\n=== THRESHOLD-ADJUSTED (0.25 cutoff) ===\n")
print(confusionMatrix(as.factor(preds_adj), as.factor(test_c$Churn)))

train_balanced <- upSample(x = train_c %>% select(-Churn),
                           y = train_c$Churn,
                           yname = "Churn")

cat("\nBalanced training set class counts:\n")
print(table(train_balanced$Churn))

log_model_balanced <- glm(Churn ~ `Customer service calls` + `International plan` +
                            `Total day minutes` + `Account length`,
                          data = train_balanced, family = "binomial")

probs_balanced <- predict(log_model_balanced, test_c, type = "response")
preds_balanced <- ifelse(probs_balanced > 0.5, "TRUE", "FALSE")

cat("\n=== BALANCED TRAINING MODEL (0.5 cutoff) ===\n")
print(confusionMatrix(as.factor(preds_balanced), as.factor(test_c$Churn)))

saveRDS(log_model_balanced, "churn_prediction_model.rds")

iris_data <- read_csv("1) iris.csv")

iris_numeric <- iris_data %>% select(where(is.numeric))

set.seed(42)
clusters <- kmeans(scale(iris_numeric), centers = 3)

iris_data$Cluster <- as.factor(clusters$cluster)
cat("\nCluster sizes:\n")
print(table(iris_data$Cluster))

ggplot(iris_data, aes(x = sepal_length, y = petal_length, color = Cluster)) +
  geom_point(size = 3) +
  labs(title = "Customer/Market Segments via K-Means Clustering")
ggsave("clustering_segments.png")

cat("\n=== SCRIPT COMPLETE ===\n")