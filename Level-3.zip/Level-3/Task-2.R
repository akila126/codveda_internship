# ============================================================
# Level 3 | Task 1: Risk Analysis & Fraud Detection
# ============================================================

install.packages("dplyr")
install.packages("readr")
install.packages("ggplot2")


library(dplyr)
library(readr)
library(ggplot2)

churn <- read_csv("churn-bigml-80.csv")

detect_anomalies <- function(x) {
  z <- abs(scale(x))
  z > 3
}

churn$anomaly_day_mins <- detect_anomalies(churn$`Total day minutes`)
churn$anomaly_calls    <- detect_anomalies(churn$`Customer service calls`)
churn$anomaly_intl     <- detect_anomalies(churn$`Total intl charge`)

churn$is_anomaly <- churn$anomaly_day_mins | churn$anomaly_calls | churn$anomaly_intl

cat("Total anomalous accounts flagged:", sum(churn$is_anomaly), "\n")
cat("Percent of customer base:", round(mean(churn$is_anomaly)*100, 2), "%\n")

churn$risk_score <- as.numeric(churn$anomaly_day_mins) +
  as.numeric(churn$anomaly_calls) +
  as.numeric(churn$anomaly_intl)

cat("\nRisk score (v1) distribution:\n")
print(table(churn$risk_score))

cat("\nChurn rate by combined risk score (v1):\n")
print(churn %>%
        group_by(risk_score) %>%
        summarise(churn_rate = mean(Churn), n = n()))

cat("\n=== INDIVIDUAL ANOMALY TYPE COUNTS ===\n")
cat("Day-minute anomalies:", sum(churn$anomaly_day_mins), "\n")
cat("Service-call anomalies:", sum(churn$anomaly_calls), "\n")
cat("Intl-charge anomalies:", sum(churn$anomaly_intl), "\n")

cat("\n=== CHURN RATE BY DAY-MINUTE ANOMALY ===\n")
print(churn %>% group_by(anomaly_day_mins) %>%
        summarise(churn_rate = mean(Churn), n = n()))

cat("\n=== CHURN RATE BY SERVICE-CALL ANOMALY ===\n")
print(churn %>% group_by(anomaly_calls) %>%
        summarise(churn_rate = mean(Churn), n = n()))

cat("\n=== CHURN RATE BY INTL-CHARGE ANOMALY ===\n")
print(churn %>% group_by(anomaly_intl) %>%
        summarise(churn_rate = mean(Churn), n = n()))

cat("\n=== WHY v2? ===\n")
cat("Intl-charge anomalies churned at 5.3% vs. 14.6% baseline —\n")
cat("that's a sign of a healthy, high-usage customer, not risk.\n")
cat("v2 excludes it so the score only reflects real risk signals.\n\n")

churn$risk_score_v2 <- as.numeric(churn$anomaly_day_mins) +
  as.numeric(churn$anomaly_calls)

cat("Risk score (v2) distribution:\n")
print(table(churn$risk_score_v2))

cat("\nChurn rate by combined risk score (v2):\n")
print(churn %>%
        group_by(risk_score_v2) %>%
        summarise(churn_rate = mean(Churn), n = n()))

ggplot(churn, aes(x = as.factor(risk_score_v2), fill = Churn)) +
  geom_bar(position = "fill") +
  labs(title = "Churn Rate by Risk Score (v2 — excludes intl-charge flag)",
       x = "Risk Score (day-minute + service-call anomalies)", y = "Proportion")
ggsave("risk_score_churn_v2.png")

cat("\n=== SCRIPT COMPLETE ===\n")