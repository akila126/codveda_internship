# ============================================================
# Level 1 | Task 2: Data Cleaning
# ============================================================

install.packages("dplyr")
install.packages("readr")
install.packages("ggplot2")
install.packages("stringr", type = "binary")
install.packages("tidyr", type = "binary")

library(dplyr)
library(readr)
library(ggplot2)
library(stringr)
library(tidyr)

df <- read_csv("3) Sentiment dataset.csv")

glimpse(df)
colSums(is.na(df))
sum(duplicated(df))

df <- df %>% select(-`...1`, -`Unnamed: 0`)

df <- df %>%
  mutate(across(where(is.character), str_trim))

df <- df %>%
  mutate(
    Sentiment = str_to_title(Sentiment),
    Platform  = str_to_title(Platform)
  )

df <- df %>%
  mutate(Timestamp = as.POSIXct(Timestamp, format = "%Y-%m-%d %H:%M:%S"))

df <- df %>%
  mutate(
    Likes = replace_na(Likes, 0),
    Retweets = replace_na(Retweets, 0)
  ) %>%
  drop_na(Text, Sentiment)

cap_outliers <- function(x) {
  q1 <- quantile(x, 0.25, na.rm = TRUE)
  q3 <- quantile(x, 0.75, na.rm = TRUE)
  iqr <- q3 - q1
  pmin(pmax(x, q1 - 1.5*iqr), q3 + 1.5*iqr)
}

df <- df %>%
  mutate(Likes = cap_outliers(Likes),
         Retweets = cap_outliers(Retweets))

df <- df %>% distinct()

write_csv(df, "sentiment_cleaned.csv")
nrow(df)