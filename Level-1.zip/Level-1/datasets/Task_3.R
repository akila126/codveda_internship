# ============================================================
# Level 1 | Task 3: Exploratory Data Analysis (EDA)
# ============================================================

install.packages("dplyr")
install.packages("readr")
install.packages("ggplot2")
install.packages("reshape2")

library(dplyr)
library(readr)
library(ggplot2)
library(reshape2)

columns <- c("CRIM","ZN","INDUS","CHAS","NOX","RM","AGE","DIS",
             "RAD","TAX","PTRATIO","B","LSTAT","MEDV")

df <- read_table("4) house Prediction Data Set.csv", col_names = columns)

glimpse(df)
colSums(is.na(df))

summary(df)

sapply(df, sd)

get_mode <- function(x) {
  uniq_x <- unique(x)
  uniq_x[which.max(tabulate(match(x, uniq_x)))]
}
sapply(df, get_mode)

z_scores <- abs(scale(df$MEDV))
outlier_count <- sum(z_scores > 3)
cat("Outliers in MEDV (|z| > 3):", outlier_count, "\n")

cor_matrix <- cor(df)

cor_with_medv <- cor_matrix[, "MEDV"] %>%
  sort(decreasing = TRUE)
print(cor_with_medv)

ggplot(df, aes(x = MEDV)) +
  geom_histogram(bins = 30, fill = "steelblue", color = "white") +
  labs(title = "Distribution of Median Home Value",
       x = "Median Home Value ($1000s)", y = "Number of Towns")
ggsave("01_medv_histogram.png", width = 7, height = 5)

ggplot(df, aes(x = RM, y = MEDV)) +
  geom_point(alpha = 0.5, color = "steelblue") +
  geom_smooth(method = "lm", color = "red") +
  labs(title = "Average Rooms per Dwelling vs. Median Home Value",
       x = "Average Rooms (RM)", y = "Median Home Value ($1000s)")
ggsave("02_rooms_vs_value.png", width = 7, height = 5)

ggplot(df, aes(x = LSTAT, y = MEDV)) +
  geom_point(alpha = 0.5, color = "steelblue") +
  geom_smooth(method = "lm", color = "red") +
  labs(title = "% Lower-Status Population vs. Median Home Value",
       x = "LSTAT (%)", y = "Median Home Value ($1000s)")
ggsave("03_lstat_vs_value.png", width = 7, height = 5)

melted_corr <- melt(cor_matrix)

ggplot(melted_corr, aes(Var1, Var2, fill = value)) +
  geom_tile() +
  geom_text(aes(label = round(value, 2)), size = 2.5) +
  scale_fill_gradient2(low = "blue", high = "red", mid = "white",
                       midpoint = 0, limit = c(-1, 1)) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(title = "Correlation Heatmap — Housing Dataset", x = "", y = "")
ggsave("04_correlation_heatmap.png", width = 9, height = 8)

cat("Saved 4 visualizations to your working directory.\n")

cor_no_target <- cor_with_medv[names(cor_with_medv) != "MEDV"]
top_positive <- names(cor_no_target)[which.max(cor_no_target)]
top_negative <- names(cor_no_target)[which.min(cor_no_target)]

cat("\n=== KEY INSIGHTS ===\n")
cat("Strongest positive driver of home value:", top_positive,
    "(corr =", round(max(cor_no_target), 2), ")\n")
cat("Strongest negative driver of home value:", top_negative,
    "(corr =", round(min(cor_no_target), 2), ")\n")
cat("Average home value: $", round(mean(df$MEDV), 1), "k\n")
cat("Median home value: $", round(median(df$MEDV), 1), "k\n")
cat("Outlier towns (|z| > 3):", outlier_count, "\n")