# ============================================================
# Level 2 | Task 3: Statistical Analysis
# ============================================================

install.packages("dplyr")
install.packages("readr")

library(dplyr)
library(readr)

df <- read_csv("churn-bigml-80.csv")
glimpse(df)

table(df$Churn)

t_test_result <- t.test(`Customer service calls` ~ Churn, data = df)
print(t_test_result)

chisq_result <- chisq.test(table(df$`International plan`, df$Churn))
print(chisq_result)

churn_rate <- mean(df$Churn)
cat("Overall churn rate:", round(churn_rate * 100, 2), "%\n")

intl_churn_rate <- df %>%
  filter(`International plan` == "Yes") %>%
  summarise(rate = mean(Churn))
print(intl_churn_rate)

group_a <- df %>% filter(`International plan` == "No") %>% pull(Churn)
group_b <- df %>% filter(`International plan` == "Yes") %>% pull(Churn)

prop.test(x = c(sum(group_a), sum(group_b)),
          n = c(length(group_a), length(group_b)))

n <- nrow(df)
p_hat <- mean(df$Churn)
se <- sqrt(p_hat * (1 - p_hat) / n)
ci_lower <- p_hat - 1.96 * se
ci_upper <- p_hat + 1.96 * se

cat("95% CI for churn rate: [", round(ci_lower*100, 2), "%,",
    round(ci_upper*100, 2), "%]\n")